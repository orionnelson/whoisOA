import React from 'react'

export function Result() {
  return (
    <div>Result</div>
  )
}

export default Result