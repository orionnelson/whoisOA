Windows System Internals Whois Lookup From https://markmonitor.com/
Retrieved From https://learn.microsoft.com/en-us/sysinternals/downloads/whois
Repo for my Json Wrapper https://github.com/orionnelson/whoisjson